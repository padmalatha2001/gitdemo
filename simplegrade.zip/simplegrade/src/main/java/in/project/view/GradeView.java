package in.project.view;

import java.util.List;


import in.project.model.GradeModel;
import in.project.resourse.GradeResource;

public class GradeView {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GradeResource gradeResource=new GradeResource();
		
		//Grade grade=new Grade(2,"A","Absolute",80,90,"Pass");
		//gradeResource.save(grade);
		
		List<GradeModel> grades=gradeResource.getGrades();
		
		for(GradeModel g:grades)
			System.out.println(g);

	}

}
